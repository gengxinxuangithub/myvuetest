const getters = {
  companyValue: state => state.companyValue,
  collapse: state => state.collapse,
  flagPicture: state => state.flagPicture
}

export default getters