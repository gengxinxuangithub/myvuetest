/**
 * Created by 不动的推动者 on 2018/5/2.
 */
//
export const COLLAPSE = 'COLLAPSE' //左侧边栏隐藏状态
//当前页面路由地址
//export const NOWROUTE = 'NOWROUTE'

//健康档案查询 多次使用封装下 
export const RECORDLIST = 'RECORDLIST' //左侧边栏隐藏状态


export const FLAGPICTURE = 'FLAGPICTURE' //控制图片显示否

